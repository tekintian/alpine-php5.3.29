Alpine 3.8 php 5.3.29 默认扩展目录
/usr/local/lib/php/extensions/no-debug-non-zts-20090626

PHP_INI_DIR
/usr/local/etc/php


PHP扩展配置目录
/usr/local/etc/php/conf.d


